var x_data = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
var y_data = [4,7,12,17,21,24,27,29,23,16,11,6];

$(document).ready(function(){

    //[{label:"Enero",y:4},{},{},...]

    let data = [];

    $.each(x_data, function(i){

        data.push({
            label: x_data[i],
            y: y_data[i]
        });

    });

    var options = {
        title: {
            text: "Temperatura media España"
        },
        axisY: {
            suffix: " °C",
        },
        animationEnabled: true,
        exportEnabled: true,
        data: [{

            type: "column",
            name: "Temp",
            shoInLegend: true,
            dataPoints: data
        }]
    };

    $("#chartContainer").CanvasJSChart(options);



});