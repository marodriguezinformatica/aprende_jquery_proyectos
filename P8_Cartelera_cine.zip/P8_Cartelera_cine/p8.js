var films = new Array();
var index = -1;

$(document).ready(function(){

    $("#search").click(function(){

        films = [];
        let text = $("#text").val();

        $.ajax({
            type: "GET",
            dataType: "html",
            url: "http://www.omdbapi.com/?s=" + text + "&apikey=b76b385c&page=1&type=movie&Content-Type=application/json",
            success: function(data){
                data = JSON.parse(data);
                data = data.Search;
                $.each(data, function(i){
                    films.push(data[i]);
                });

                if (films.length > 0){
                    $("#title").text(films[0].Title);
                    $("#year").text(films[0].Year);
                    let image = "<img src='" + films[0].Poster + "' />";
                    $("#poster").html(image);
                    index = 0;
                }
                else{
                    $("#title").text("No existen películas relacionadas");
                    $("#year").text("");
                    $("#poster").text("");
                }
            }
        });
    });

    $("#forward").click(function(){

        if (index == films.length - 1){
            index = 0;
        }else{
            index++;
        }

        let source = films[index].Poster;
        let image = "<img src='" + source + "' />";
        $("#title").text(films[index].Title);
        $("#year").text(films[index].Year);
        $("#poster").html(image);
    });

    $("#backward").click(function(){

        if (index == 0){
            index = films.length - 1;
        }
        else{
            index--;
        }
        
        let source = films[index].Poster;
        let image = "<img src='" + source + "' />";
        $("#title").text(films[index].Title);
        $("#year").text(films[index].Year);
        $("#poster").html(image);

    });


});